package Composite;



 public interface Decorator {   
     
     Double getPrice();
     
    }