package Composite;

import java.text.DecimalFormat;
import java.lang.Double;
import java.lang.String;



public abstract class LeafDecorator extends Leaf implements Decorator {      
    Decorator wrapped ;       
    public LeafDecorator( String d, Double p ) {  
        
        super( d,p ) ;        
        
        this.wrapped = null ;     
    } 
    
    public void wrapDecorator( Decorator w )     {
        this.wrapped = w ;   
    }         
    
    public Double getPrice() {
        if (wrapped == null )         
        {             
            return price ;        
        }        
        else         
        {            
            return price + wrapped.getPrice() ;
        }     
    } 
    
     abstract public void setOptions(  String[] options ) ; 
     
     abstract public String getDescription() ;        
     
     @Override     
     public void printDescription() {        
         System.out.println( getDescription() ) ;    
        }           
        
    } 
